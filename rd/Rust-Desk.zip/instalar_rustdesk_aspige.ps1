﻿#Requires -Version 5.1
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$RustDeskConfig   = "9JSPVdVNOVjYKp1NwNFSFZWRvhXMyQnMENTVy82bJ9WZ2IWYlFTYI12dvJ1ZtJiOikXZrJCLiIiOikGchJCLiMXZuU2ZpB3ch5CZyJiOikXYsVmciwiIzVmLldWawNXYuQmciojI0N3boJye"
$RustDeskPassword = "Jmcea.005"

function Write-Info($msg)  { Write-Host "[INFO] $msg" -ForegroundColor Cyan }
function Write-Ok($msg)    { Write-Host "[OK]   $msg" -ForegroundColor Green }
function Write-Warn2($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err2($msg)  { Write-Host "[ERR]  $msg" -ForegroundColor Red }

function Ensure-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)

    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Info "Solicitando privilegios de administrador..."
        Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
        exit
    }
}

function Get-LatestRustDeskUrl {
    Write-Info "Buscando la ultima version oficial de RustDesk..."
    $release = Invoke-WebRequest -Uri "https://github.com/rustdesk/rustdesk/releases/latest" -MaximumRedirection 0 -ErrorAction SilentlyContinue -UseBasicParsing
    $target = $release.Headers.Location

    if (-not $target) {
        $target = (Invoke-WebRequest -Uri "https://github.com/rustdesk/rustdesk/releases/latest" -UseBasicParsing).BaseResponse.ResponseUri.AbsoluteUri
    }

    if (-not $target) {
        throw "No pude localizar la ultima release de RustDesk."
    }

    $version = Split-Path $target -Leaf
    if (-not $version) {
        throw "No pude obtener la version de RustDesk."
    }

    $url = "https://github.com/rustdesk/rustdesk/releases/download/$version/rustdesk-$version-x86_64.exe"
    Write-Ok "Version detectada: $version"
    return $url
}

function Download-RustDesk {
    $tmp = Join-Path $env:TEMP "rustdesk-aspige.exe"
    $url = Get-LatestRustDeskUrl

    Write-Info "Descargando RustDesk desde: $url"
    Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing

    if (!(Test-Path $tmp)) {
        throw "No se pudo descargar RustDesk."
    }

    Write-Ok "Descarga completada: $tmp"
    return $tmp
}

function Install-RustDesk($installerPath) {
    Write-Info "Instalando RustDesk..."
    $p = Start-Process -FilePath $installerPath -ArgumentList "--silent-install" -PassThru -Wait

    if ($p.ExitCode -ne 0) {
        throw "La instalacion devolvio codigo $($p.ExitCode)."
    }

    $exe1 = "C:\Program Files\RustDesk\rustdesk.exe"
    $exe2 = "${env:ProgramFiles(x86)}\RustDesk\rustdesk.exe"

    for ($i = 0; $i -lt 30; $i++) {
        if ((Test-Path $exe1) -or (Test-Path $exe2)) {
            break
        }
        Start-Sleep -Seconds 2
    }

    if (Test-Path $exe1) {
        Write-Ok "RustDesk instalado en: $exe1"
        return $exe1
    }

    if (Test-Path $exe2) {
        Write-Ok "RustDesk instalado en: $exe2"
        return $exe2
    }

    throw "RustDesk no quedo instalado."
}

function Ensure-Service($exe) {
    $svc = Get-Service -Name "RustDesk" -ErrorAction SilentlyContinue

    if (-not $svc) {
        Write-Info "Instalando servicio RustDesk..."
        $p = Start-Process -FilePath $exe -ArgumentList "--install-service" -PassThru -Wait
        Start-Sleep -Seconds 5
        $svc = Get-Service -Name "RustDesk" -ErrorAction SilentlyContinue

        if ($p.ExitCode -ne 0 -and -not $svc) {
            throw "No se pudo instalar el servicio RustDesk. ExitCode: $($p.ExitCode)"
        }
    }

    if (-not $svc) {
        throw "No encontre el servicio RustDesk despues de intentar instalarlo."
    }

    if ($svc.Status -ne "Running") {
        Write-Info "Iniciando servicio RustDesk..."
        Start-Service -Name "RustDesk"
        Start-Sleep -Seconds 5
        $svc.Refresh()
    }

    if ($svc.Status -ne "Running") {
        throw "El servicio RustDesk no quedo arrancado."
    }

    Write-Ok "Servicio RustDesk listo."
}

function Stop-RustDeskProcesses {
    Write-Info "Cerrando procesos de RustDesk abiertos..."
    Get-Process -Name "rustdesk" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
}

function Invoke-RustDeskCli($exe, [string[]]$arguments, [string]$desc) {
    Write-Info $desc

    $wd = Split-Path $exe -Parent
    $p = Start-Process -FilePath $exe `
                       -ArgumentList $arguments `
                       -WorkingDirectory $wd `
                       -Wait `
                       -PassThru `
                       -NoNewWindow

    if ($p.ExitCode -ne 0) {
        throw "$desc fallo. ExitCode: $($p.ExitCode)"
    }
}

function Apply-RustDeskConfig($exe, $cfg, $pw) {
    Stop-RustDeskProcesses

    Invoke-RustDeskCli -exe $exe -arguments @("--config", $cfg) -desc "Aplicando config del servidor"
    Start-Sleep -Seconds 3

    Invoke-RustDeskCli -exe $exe -arguments @("--password", $pw) -desc "Aplicando contrasena permanente"
    Start-Sleep -Seconds 2
}

function Restart-RustDeskService {
    $svc = Get-Service -Name "RustDesk" -ErrorAction SilentlyContinue
    if ($svc) {
        Write-Info "Reiniciando servicio..."
        Restart-Service -Name "RustDesk" -Force
        Start-Sleep -Seconds 5
        $svc = Get-Service -Name "RustDesk"
        if ($svc.Status -ne "Running") {
            throw "El servicio RustDesk no arranco tras reiniciarlo."
        }
        Write-Ok "Servicio reiniciado."
    }
}

function Get-RustDeskId($exe) {
    $id = & $exe --get-id 2>$null
    if ($LASTEXITCODE -eq 0 -and $id) {
        return ($id | Select-Object -First 1).Trim()
    }
    return $null
}

function Start-RustDesk($exe) {
    Write-Info "Abriendo RustDesk..."
    Start-Process -FilePath $exe | Out-Null
}

Ensure-Admin

$installer = Download-RustDesk
$exe = Install-RustDesk -installerPath $installer
Ensure-Service -exe $exe
Apply-RustDeskConfig -exe $exe -cfg $RustDeskConfig -pw $RustDeskPassword
Restart-RustDeskService

$id = Get-RustDeskId -exe $exe
Start-RustDesk -exe $exe

Write-Host ""
Write-Ok "Terminado."
if ($id) {
    Write-Host "ID: $id" -ForegroundColor White
}
Write-Host "Password fija: $RustDeskPassword" -ForegroundColor White
Write-Host ""
Write-Host "Comprueba en Configuracion > Red si quedaron aplicados ID/Relay/API/Key." -ForegroundColor White
Write-Host ""