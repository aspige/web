@echo off
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c %~f0' -Verb RunAs"
    exit
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_rustdesk_aspige.ps1"